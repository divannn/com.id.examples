import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author idanilov
 *
 */
public class GenerateStudies extends Task {

	public static final String XML_TYPE = "xml";
	public static final String XML_ENCODING = "UTF-8";

	private String source;
	private String target;
	private String ids;
	private String xpath;
	private boolean omitXmlDecl;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public boolean isOmitXmlDecl() {
		return omitXmlDecl;
	}

	public void setOmitXmlDecl(boolean omitXmlDecl) {
		this.omitXmlDecl = omitXmlDecl;
	}

	public String getXpath() {
		return xpath;
	}

	public void setXpath(String xpath) {
		this.xpath = xpath;
	}

	@Override
	public void execute() throws BuildException {
		log(">>> source: " + source);
		log(">>> target: " + target);
		log(">>> xpath: " + xpath);
		generate();
	}

	private void generate() throws BuildException {
		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			DocumentBuilder builder = domFactory.newDocumentBuilder();
			Document doc = builder.parse(source);
			Document out = XmlUtil.createEmptyDocument(doc.getDocumentElement().getNodeName());
			XPath xPath = XPathFactory.newInstance().newXPath();
			if (xpath.trim().length() > 0) {
				XPathExpression expr = xPath.compile(xpath);
				Object result = expr.evaluate(doc, XPathConstants.NODESET);
				NodeList nodes = (NodeList) result;
				//System.err.println(">> nodes found :" + nodes.getLength());
				for (int i = 0; i < nodes.getLength(); i++) {
					Node copy = out.importNode(nodes.item(i), true);
					out.getDocumentElement().appendChild(copy);
				}
			}
			XmlUtil.writeXML(out, new FileOutputStream(target), true, 120, omitXmlDecl);
		} catch (Exception e) {
			throw new BuildException("Failed to generate studies definition file", e);
		}
	}

	public static void main(String[] args) throws Exception {
/*		GenerateStudies task = new GenerateStudies();
		task.setSource("allStudiesDefinitions.xml");
		task.setTarget("definitionsList.xml");
		String q = "@id='ADX' or @id='ZigZag'";
		task.setXpath("//indicators/indicator[" + q + "]");
		task.execute();*/
	}

}
