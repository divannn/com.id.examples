import java.io.IOException;
import java.io.OutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;

/**
 * @author idanilov
 *
 */
class XmlUtil {

	public static final String XML_TYPE = "xml";
	public static final String XML_ENCODING = "UTF-8";

	public static Document createEmptyDocument(String rootName) throws ParserConfigurationException {
		if (rootName == null) {
			throw new IllegalArgumentException();
		}
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = docFactory.newDocumentBuilder();
		Document result = builder.newDocument();
		Element root = result.createElement(rootName);
		result.appendChild(root);
		return result;
	}

	public static void writeXML(final Document doc, final OutputStream os, final boolean indenting,
			final int lineWidth, final boolean omitXmlDecl) throws IOException {
		XMLSerializer serializer = null;
		OutputFormat outputFormat = new OutputFormat(XML_TYPE, XML_ENCODING, false);
		outputFormat.setOmitXMLDeclaration(omitXmlDecl);
		if (indenting) {
			outputFormat.setIndenting(indenting);
			outputFormat.setLineWidth(lineWidth);
		}
		serializer = new XMLSerializer(os, outputFormat);
		serializer.serialize(doc);
	}

}
